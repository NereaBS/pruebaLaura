package com.gildedrose;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class BackStageTest {

    static final String BACKSTAGE = "Backstage passes to a TAFKAL80ETC concert";
    static final int BACKSTAGE_QUALITY = 20;
    static final int SELLIN_PASSED = 0;
    static final int SELLIN_GREATER_THAN_TEN = 11;
    static final int SELLIN_LESS_THAN_FIVE = 3;
    static final int BACKSTAGE_DATE_PASSED_QUALITY_EXPECTED = 0;
    static final int BACKSTAGE_DATE_NOT_PASSED_QUALITY_EXPECTED = 21;
    static final int BACKSTAGE_QUALITY_EXPECTED = 23;
    static final BackStageItem BACKSTAGE_ITEM = new BackStageItem();

    @Test
    void checkBackStageQualityDateHasPassedTest() {
        Item[] items = new Item[] { new Item(BACKSTAGE, SELLIN_PASSED, BACKSTAGE_QUALITY) };
        GildedRose app = new GildedRose(items);
        app.updateQuality();
        assertEquals(BACKSTAGE_DATE_PASSED_QUALITY_EXPECTED,app.items[0].quality);
    }
    @Test
    void checkBackStageQualityDateHasNotPassedTest() {
        Item[] items = new Item[] { new Item(BACKSTAGE, SELLIN_GREATER_THAN_TEN, BACKSTAGE_QUALITY) };
        GildedRose app = new GildedRose(items);
        app.updateQuality();
        assertEquals(BACKSTAGE_DATE_NOT_PASSED_QUALITY_EXPECTED,app.items[0].quality);
    }
    @Test
    void checkBackstageSellInGreaterThanTenTest() {
        Item[] items = new Item[] { new Item(BACKSTAGE, SELLIN_GREATER_THAN_TEN, BACKSTAGE_QUALITY) };
        GildedRose app = new GildedRose(items);
        assertTrue(BACKSTAGE_ITEM.checkBackStageSellInGreaterThanTen(app.items[0]));
    }
    @Test
    void checkBackstageSellInLessThanFiveTest() {
        Item[] items = new Item[] { new Item(BACKSTAGE, SELLIN_LESS_THAN_FIVE, BACKSTAGE_QUALITY) };
        GildedRose app = new GildedRose(items);
        assertTrue(BACKSTAGE_ITEM.checkBackStageSellInLessThanFive(app.items[0]));
    }
    @Test
    void checkBackStageUpdateQualityTest() {
        Item[] items = new Item[] { new Item(BACKSTAGE, SELLIN_LESS_THAN_FIVE, BACKSTAGE_QUALITY) };
        GildedRose app = new GildedRose(items);
        BACKSTAGE_ITEM.updateBackStage(items[0]);
        assertEquals(BACKSTAGE_QUALITY_EXPECTED,app.items[0].quality);
    }


}

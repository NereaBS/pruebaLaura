package com.gildedrose;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static com.gildedrose.GildedRose.UTILITIES;
import static org.junit.jupiter.api.Assertions.*;

public class AgedBrieTest {
    static final int SELLIN_EXPECTED = 4;
    static final int AGED_BRIE_DATE_PASSED_QUALITY_EXPECTED = 22;
    static final int AGED_BRIE_DATE_NOT_PASSED_QUALITY_EXPECTED = 21;
    static final int NEGATIVE_QUALITY = -4;
    static final int AGED_BRIE_QUALITY_DEFAULT = 20;
    static final int AGED_BRIE_QUALITY_CLOSE_50 = 49;
    static final int AGED_BRIE_QUALITY_50 = 50;
    static final int SELLIN_PASSED = 0;
    static final int SELLIN_DEFAULT = 5;
    static final String AGED_BRIE = "Aged Brie";
    static final AgedBrieItem AGEDBRIE_ITEM = new AgedBrieItem();

    @Test
    void checkAgedBrieQualityDateHasPassedTest() {
        Item[] items = new Item[] { new Item(AGED_BRIE, SELLIN_PASSED, AGED_BRIE_QUALITY_DEFAULT) };
        GildedRose app = new GildedRose(items);
        app.updateQuality();
        assertEquals(AGED_BRIE_DATE_PASSED_QUALITY_EXPECTED,items[0].quality);
    }
    @Test
    void checkAgedBrieQualityDateHasNotPassedTest() {
        Item[] items = new Item[] { new Item(AGED_BRIE, SELLIN_DEFAULT, AGED_BRIE_QUALITY_DEFAULT) };
        GildedRose app = new GildedRose(items);
        app.updateQuality();
        assertEquals(AGED_BRIE_DATE_NOT_PASSED_QUALITY_EXPECTED,app.items[0].quality);
    }
    @Test
    void checkItemUpdateQualityInRange50Test() {
        Item[] items = new Item[] { new Item(AGED_BRIE, SELLIN_DEFAULT, AGED_BRIE_QUALITY_50)};
        GildedRose app = new GildedRose(items);
        app.updateQuality();
        assertEquals(AGED_BRIE_QUALITY_50,app.items[0].quality);
    }
    @Test
    void checkAgedBrieQualityInRange50Test() {
        Item[] items = new Item[] { new Item(AGED_BRIE, SELLIN_DEFAULT, AGED_BRIE_QUALITY_CLOSE_50) };
        GildedRose app = new GildedRose(items);
        assertTrue(UTILITIES.checkQualityInRange50(app.items[0]));
    }
    @Test
    void checkAgedBrieQualityNotInRange50Test() {
        Item[] items = new Item[] { new Item(AGED_BRIE, SELLIN_DEFAULT, AGED_BRIE_QUALITY_50) };
        GildedRose app = new GildedRose(items);
        assertFalse(UTILITIES.checkQualityInRange50(app.items[0]));
    }
    @Test
    void checkAgedBrieUpdateQualityTest() {
        Item[] items = new Item[] { new Item(AGED_BRIE, SELLIN_PASSED, AGED_BRIE_QUALITY_DEFAULT) };
        GildedRose app = new GildedRose(items);
        AGEDBRIE_ITEM.updateAgedBrie(items[0]);
        assertEquals(AGED_BRIE_DATE_PASSED_QUALITY_EXPECTED,getFirstItemQuality(app));
    }

    int getFirstItemQuality(GildedRose app){
        return app.items[0].quality;
    }
}

package com.gildedrose;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class SulfurasTest {

    static final String SULFURAS = "Sulfuras, Hand of Ragnaros";

    static final int SELLIN_DEFAULT = 5;
    static final int SULFURAS_QUALITY = 80;

    @Test
    void checkSulfurasStillEqualsTest() {
        //Arrange
        Item[] items = new Item[] { new Item(SULFURAS, SELLIN_DEFAULT, SULFURAS_QUALITY) };
        GildedRose app = new GildedRose(items);
        //Act
        app.updateQuality();
        //Assert
        assertEquals(SELLIN_DEFAULT,app.items[0].sellIn);
        assertEquals(SULFURAS_QUALITY,app.items[0].quality);
    }
}

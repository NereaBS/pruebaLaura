package com.gildedrose;

public class Quality {

    private int value;
    static final int QUALITY_MAX_LIMIT = 50;

    public Quality(Integer quality) {
        value = quality;
    }

    public void increaseInOne(){
        final int INCREMENT_VALUE = 1;
        if (value + INCREMENT_VALUE > QUALITY_MAX_LIMIT) {
            value = QUALITY_MAX_LIMIT;
            return;
        }
        value++;
    }
    public void decreaseQuality(Item item){
        value--;
    }

    public int getValue() {
        return value;
    }
}

package com.gildedrose;

import static com.gildedrose.GildedRose.UTILITIES;

public class AgedBrieItem {

    public void updateAgedBrie(Item item) {
        Quality quality = new Quality(item.quality);
        quality.increaseInOne();
        if(!UTILITIES.checkSellInGreaterThanCero(item)) {
            quality.increaseInOne();
        }
        item.quality = quality.getValue();
    }


}

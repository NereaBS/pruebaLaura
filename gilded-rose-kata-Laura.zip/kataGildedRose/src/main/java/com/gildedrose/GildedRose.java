package com.gildedrose;

class GildedRose {
    Item[] items;
    static final String AGED_BRIE = "Aged Brie";
    static final String SULFURAS = "Sulfuras";
    static final String BACKSTAGE = "Backstage";

    static final Utilities UTILITIES = new Utilities();
    static final BackStageItem BACKSTAGE_ITEM = new BackStageItem();
    static final AgedBrieItem AGEDBRIE_ITEM = new AgedBrieItem();

    public GildedRose(Item[] items) {
        this.items = items;
    }
    public void updateQuality() {
        for (Item item : items) {
            if(!itemIsSulfuras(item.name)) {
                if (UTILITIES.checkNonNegativeQuality(item)) {
                    if (itemIsAgedBrie(item.name)) {
                        AGEDBRIE_ITEM.updateAgedBrie(item);
                    } else if (itemIsBackstage(item.name)) {
                        if (!UTILITIES.checkSellInGreaterThanCero(item)){
                            item.quality = 0;
                        }else BACKSTAGE_ITEM.updateBackStage(item);
                    }else {
                        updateItemDefault(item);
                    }
                }
                UTILITIES.decreaseSellIn(item);
            }
        }
    }
    private void updateItemDefault(Item item) {
        UTILITIES.decreaseQuality(item);
        if (!UTILITIES.checkSellInGreaterThanCero(item)){
            UTILITIES.decreaseQuality(item);
        }
    }

    private boolean itemIsBackstage(String name) {
        return name.contains(BACKSTAGE);
    }
    private boolean itemIsAgedBrie(String name) {
        return name.contains(AGED_BRIE);
    }
    private boolean itemIsSulfuras(String name) {
        return name.contains(SULFURAS);
    }


}

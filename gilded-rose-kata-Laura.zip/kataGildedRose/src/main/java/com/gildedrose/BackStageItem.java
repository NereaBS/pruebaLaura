package com.gildedrose;

import static com.gildedrose.GildedRose.UTILITIES;

public class BackStageItem {

    static final int SELLIN_TEN = 10;
    static final int SELLIN_FIVE = 5;

    public void updateBackStage(Item item){
        if(UTILITIES.checkQualityInRange50(item)){
            UTILITIES.increaseQuality(item);
            if (!checkBackStageSellInGreaterThanTen(item)){
                UTILITIES.increaseQuality(item);
            }
            if(checkBackStageSellInLessThanFive(item)){
                UTILITIES.increaseQuality(item);
            }
        }
    }
    public boolean checkBackStageSellInGreaterThanTen(Item item) {
        return item.sellIn > SELLIN_TEN;
    }
    public boolean checkBackStageSellInLessThanFive(Item item) {
        return item.sellIn <= SELLIN_FIVE;
    }
}
